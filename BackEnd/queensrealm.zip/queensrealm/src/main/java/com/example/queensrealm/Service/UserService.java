package com.example.queensrealm.Service;

import java.security.Principal;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.queensrealm.Entity.user.UserInfo;
import com.example.queensrealm.Repository.UserRepository;
import com.example.queensrealm.dto.request.ChangePasswordRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepo;

    public String changePassword(ChangePasswordRequest request, Principal connectedUser){
        var user = (UserInfo) ((UsernamePasswordAuthenticationToken) connectedUser).getPrincipal();

        if(!passwordEncoder.matches(request.getCurrPassword(), user.getPassword())){
            return "Wrong Password";
        }
       if(!request.getNewPassword().equals(request.getConfirmPassword())){
            return "Passwords do not match";
       }

       user.setPassword(passwordEncoder.encode(request.getNewPassword()));
       userRepo.save(user);
       return "Password Changed Successfully";
    }
}
