package com.example.queensrealm.Entity.courses;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Lesson {
    @Id
    private Integer id;
    private String lessonName;
    private String duration;
}
