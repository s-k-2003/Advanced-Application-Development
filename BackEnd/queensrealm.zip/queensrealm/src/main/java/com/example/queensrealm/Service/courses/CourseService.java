package com.example.queensrealm.Service.courses;

import org.springframework.stereotype.Service;

import com.example.queensrealm.Entity.courses.Courses;
import com.example.queensrealm.Repository.courses.CourseRepository;
import com.example.queensrealm.dto.request.CourseRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CourseService {
    private final CourseRepository courseRepository;

    public String addCourses(CourseRequest request){
        System.out.println(request.getCoursename());
        var courses = Courses.builder()
            .courseid(request.getCourseid())
            .coursename(request.getCoursename())
            .level(request.getLevel())
            .description(request.getDescription())
            .duration(request.getDuration())
            .lessoncount(request.getLessoncount())
            .price(request.getPrice())
            .ratings(request.getRatings())
            .lessons(request.getLessons())
            .build();
        courseRepository.save(courses);
        return "Courses added successfully";
    }
}
