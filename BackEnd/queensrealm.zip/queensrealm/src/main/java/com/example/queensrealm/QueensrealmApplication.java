package com.example.queensrealm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueensrealmApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueensrealmApplication.class, args);
	}

}
