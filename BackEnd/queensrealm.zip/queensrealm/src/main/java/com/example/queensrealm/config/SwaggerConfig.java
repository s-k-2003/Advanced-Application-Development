package com.example.queensrealm.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.utilits.Constants;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import static io.swagger.v3.oas.models.security.SecurityScheme.Type.HTTP;

@Configuration
public class SwaggerConfig {
    @Bean
    public OpenAPI openAPI() {
            return new OpenAPI()
                            .info(new Info()
                                            .title(Constants.SWAGGER_INFO_TITLE)
                                            .description(Constants.SWAGGER_INFO_DESCRIPTION)
                                            .version(Constants.SWAGGER_INFO_VERSION)
                                            .contact(new Contact()
                                                            .name(Constants.SWAGGER_INFO_CONTACT_NAME)
                                                            .email(Constants.SWAGGER_INFO_CONTACT_EMAIL)
                                                            .url(Constants.SWAGGER_INFO_CONTACT_URL))
                                            .license(new License()
                                                            .name(Constants.SWAGGER_INFO_LISENCE_NAME)
                                                            .url(Constants.SWAGGER_INFO_LISENCE_URL)))
                            .servers(List.of(new Server().url(Constants.JWT_LOCALHOST_URL)))
                            .addSecurityItem(new SecurityRequirement()
                                            .addList(Constants.JWT_SECURITY_SCHEME_NAME))
                            .components(new Components()
                                            .addSecuritySchemes(
                                                Constants.JWT_SECURITY_SCHEME_NAME, new SecurityScheme()
                                                                            .name(Constants.JWT_SECURITY_SCHEME_NAME)
                                                                            .type(HTTP)
                                                                            .scheme(Constants.JWT_SCHEME)
                                                                            .description(Constants.JWT_DESCRIPTION)
                                                                            .bearerFormat(Constants.JWT_BEARER_FORMAT)));
    }
}
