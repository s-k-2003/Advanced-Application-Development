package com.example.queensrealm.dto.request;

import java.util.List;

import com.example.queensrealm.Entity.courses.Lesson;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CourseRequest {
    private String courseid;
    private String coursename;
    private String level;
    private String ratings;
    private String description;
    private String duration;
    private String lessoncount;
    private float price;
    private List<Lesson> lessons;
}
