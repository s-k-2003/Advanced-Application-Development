package com.example.queensrealm.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import com.example.queensrealm.Entity.user.Permission;
import com.example.queensrealm.Entity.user.Role;
import com.example.utilits.Constants;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfiguration {

    private final JwtAuthenticationFilter JwtAuthFilter;
    private final AuthenticationProvider authenticationProvider;
    private final LogoutHandler logoutHandler;
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
        http
            .csrf(csrf -> csrf.disable())
            // .authorizeHttpRequests(authorize -> authorize.requestMatchers("/users/v1/auth/**").permitAll()
            .authorizeHttpRequests(authorize -> authorize.requestMatchers(Constants.WHITELIST_URL).permitAll()
                .requestMatchers("/users/v1/user/**").hasAnyRole(Role.ADMIN.name(), Role.USER.name())

                
                .requestMatchers(HttpMethod.GET, "/users/v1/user/**").hasAnyAuthority(Permission.USER_READ.name())
                .requestMatchers(HttpMethod.POST, "/users/v1/user/**").hasAnyAuthority(Permission.USER_CREATE.name())
                .requestMatchers(HttpMethod.PUT, "/users/v1/user/**").hasAnyAuthority(Permission.USER_UPDATE.name())
                .requestMatchers(HttpMethod.DELETE, "/users/v1/user/**").hasAnyAuthority(Permission.USER_DELETE.name())

                .requestMatchers("/users/v1/admin/**").hasAnyRole(Role.ADMIN.name())

                .requestMatchers(HttpMethod.GET, "/users/v1/admin/**").hasAnyAuthority(Permission.ADMIN_READ.name())
                .requestMatchers(HttpMethod.POST, "/users/v1/admin/**").hasAnyAuthority(Permission.ADMIN_CREATE.name())
                .requestMatchers(HttpMethod.PUT, "/users/v1/admin/**").hasAnyAuthority(Permission.ADMIN_UPDATE.name())
                .requestMatchers(HttpMethod.DELETE, "/users/v1/admin/**").hasAnyAuthority(Permission.ADMIN_DELETE.name())


            .anyRequest()
            .authenticated())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authenticationProvider(authenticationProvider)
            .addFilterBefore(JwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
            .logout(logout -> 
            logout
            .logoutUrl("/users/v1/logout")
            .addLogoutHandler(logoutHandler)
            .logoutSuccessHandler((request, response, authentication) -> SecurityContextHolder.clearContext())) 
            ;

        return http.build();
    }
}
