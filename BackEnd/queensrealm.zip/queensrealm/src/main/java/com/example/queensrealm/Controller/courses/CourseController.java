package com.example.queensrealm.Controller.courses;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.queensrealm.Service.courses.CourseService;
import com.example.queensrealm.dto.request.CourseRequest;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/users/v1/admin/courses")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;


    @PostMapping("/create")
    @PreAuthorize("hasAuthority('admin:CREATE')")
    public String createCourse(
        CourseRequest request
    ){
        return courseService.addCourses(request);
    }
}
