package com.example.queensrealm.Controller.token;

import java.util.Optional;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.queensrealm.Entity.token.Token;
import com.example.queensrealm.Repository.token.TokenRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/users/v1/user/token")
@PreAuthorize("hasRole('USER')")
@RequiredArgsConstructor
public class TokenController {
    private final TokenRepository tokenRepository;

    @GetMapping("/view/{email}")
    @PreAuthorize("hasAuthority('user:READ')")
    public Optional<Token> viewToken(@PathVariable String email){
        return tokenRepository.findByUser(email);
        
    }

}
